// src/handlers/messages.js
import AWS from "aws-sdk";
import crypto from "crypto";

const dynamodb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.MESSAGES_TABLE || "chatr-messages";
const GROUPS_TABLE = process.env.GROUPS_TABLE || "chatr-groups";
const READ_TABLE = process.env.READ_TRACKING_TABLE || "chatr-read-tracking"; // 🆕 NEW

const response = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
  },
  body: JSON.stringify(body),
});

export const handler = async (event) => {
  console.log("📩 Event received:", event);
  try {
    const method = event.httpMethod;
    const path = event.path || "";
    const params = event.queryStringParameters || {};

    /* ===========================================================
       🆕 1. MARK CHAT AS READ
    =========================================================== */
    if (method === "POST" && path.endsWith("/messages/mark-read")) {
      const body = JSON.parse(event.body || "{}");
      const { chatId, username } = body;

      if (!chatId || !username)
        return response(400, {
          success: false,
          message: "Missing chatId or username",
        });

      const timestamp = new Date().toISOString();

      await dynamodb
        .put({
          TableName: READ_TABLE,
          Item: { chatid: chatId, username, lastReadTimestamp: timestamp },
        })
        .promise();

      console.log(`✅ Marked ${chatId} read for ${username} at ${timestamp}`);
      return response(200, { success: true, chatId, username, timestamp });
    }

    /* ===========================================================
       🆕 2. FETCH UNREAD COUNTS
    =========================================================== */
    if (method === "GET" && path.endsWith("/messages/unread-counts")) {
      const username = params.username;
      if (!username)
        return response(400, {
          success: false,
          message: "Missing username parameter",
        });

      console.log(`🔍 Fetching unread counts for ${username}`);

      // Get all read tracking entries for this user
      const readData = await dynamodb
        .query({
          TableName: READ_TABLE,
          KeyConditionExpression: "username = :u",
          ExpressionAttributeValues: { ":u": username },
          IndexName: undefined,
        })
        .promise()
        .catch(() => ({ Items: [] }));

      const readMap = {};
      for (const item of readData.Items || []) {
        readMap[item.chatid] = item.lastReadTimestamp;
      }

      const unreadCounts = [];

      // 1️⃣ Scan all 1-to-1 messages involving this user
      const res1 = await dynamodb
        .scan({
          TableName: TABLE_NAME,
          FilterExpression:
            "(sender = :u OR recipient = :u) AND attribute_not_exists(groupid)",
          ExpressionAttributeValues: { ":u": username },
        })
        .promise();

      const dmChats = {};
      for (const msg of res1.Items || []) {
        const other =
          msg.sender === username ? msg.recipient : msg.sender;
        if (!other) continue;
        const chatId = `CHAT#${[username, other].sort().join("#")}`;
        const lastRead = readMap[chatId];
        if (
          !lastRead ||
          new Date(msg.createdAt) > new Date(lastRead)
        ) {
          dmChats[chatId] = (dmChats[chatId] || 0) + 1;
        }
      }

      // 2️⃣ Scan all group messages
      const res2 = await dynamodb
        .scan({
          TableName: TABLE_NAME,
          FilterExpression: "attribute_exists(groupid)",
        })
        .promise();

      for (const msg of res2.Items || []) {
        if (!msg.groupid) continue;

        // Check if user is part of group
        const groupData = await dynamodb
          .get({ TableName: GROUPS_TABLE, Key: { groupid: msg.groupid } })
          .promise();

        const group = groupData.Item;
        if (!group?.members?.includes(username)) continue;

        const chatId = msg.groupid;
        const lastRead = readMap[chatId];
        if (
          !lastRead ||
          new Date(msg.createdAt) > new Date(lastRead)
        ) {
          dmChats[chatId] = (dmChats[chatId] || 0) + 1;
        }
      }

      for (const [chatId, unreadCount] of Object.entries(dmChats)) {
        unreadCounts.push({ chatId, unreadCount });
      }

      console.log(`📊 Unread summary for ${username}:`, unreadCounts);
      return response(200, unreadCounts);
    }

    /* ===========================================================
       📨 SEND MESSAGE
    =========================================================== */
    if (method === "POST") {
      const body = JSON.parse(event.body || "{}");
      const {
        sender,
        recipient,
        groupid,
        text,
        attachmentKey,
        attachmentType,
      } = body;

      if (!sender || (!recipient && !groupid)) {
        return response(400, {
          success: false,
          message: "Missing required sender or recipient/groupid",
        });
      }

      if (!text && !attachmentKey) {
        return response(400, {
          success: false,
          message: "Message must include text or an attachment",
        });
      }

      // ✅ Validate group membership before sending
      if (groupid) {
        const groupData = await dynamodb
          .get({ TableName: GROUPS_TABLE, Key: { groupid } })
          .promise();

        const group = groupData.Item;
        if (!group)
          return response(404, { success: false, message: "Group not found" });

        if (!group.members?.includes(sender))
          return response(403, {
            success: false,
            message: "You are not a member of this group",
          });
      }

      // ✅ Construct message object
      const message = {
        messageid: crypto.randomUUID(),
        sender,
        recipient: recipient || null,
        groupid: groupid || null,
        text: text || null,
        createdAt: new Date().toISOString(),
      };

      if (attachmentKey) {
        message.attachmentKey = attachmentKey;
        message.attachmentType =
          attachmentType || "application/octet-stream";
      }

      await dynamodb.put({ TableName: TABLE_NAME, Item: message }).promise();
      console.log("✅ Message saved:", message);

      return response(200, { success: true, data: message });
    }

    /* ===========================================================
       📥 FETCH MESSAGES
    =========================================================== */
    if (method === "GET") {
      const { userA, userB, groupid, username } = params;

      if (groupid) {
        const groupData = await dynamodb
          .get({ TableName: GROUPS_TABLE, Key: { groupid } })
          .promise();
        const group = groupData.Item;

        if (!group)
          return response(404, { success: false, message: "Group not found" });

        if (username && !group.members?.includes(username))
          return response(403, {
            success: false,
            message: "You are not authorized to view this group",
          });

        const res = await dynamodb
          .scan({
            TableName: TABLE_NAME,
            FilterExpression: "groupid = :gid",
            ExpressionAttributeValues: { ":gid": groupid },
            Limit: 200,
          })
          .promise();

        const sorted = (res.Items || []).sort(
          (a, b) => new Date(a.createdAt) - new Date(b.createdAt)
        );
        return response(200, { success: true, data: sorted });
      }

      if (userA && userB) {
        const res = await dynamodb
          .scan({
            TableName: TABLE_NAME,
            FilterExpression:
              "(sender = :a AND recipient = :b) OR (sender = :b AND recipient = :a)",
            ExpressionAttributeValues: { ":a": userA, ":b": userB },
            Limit: 200,
          })
          .promise();

        const sorted = (res.Items || []).sort(
          (a, b) => new Date(a.createdAt) - new Date(b.createdAt)
        );
        return response(200, { success: true, data: sorted });
      }

      return response(400, {
        success: false,
        message: "Missing query parameters",
      });
    }

    return response(405, { success: false, message: "Method not allowed" });
  } catch (err) {
    console.error("❌ Message handler error:", err);
    return response(500, {
      success: false,
      message: err.message || "Internal server error",
    });
  }
};
