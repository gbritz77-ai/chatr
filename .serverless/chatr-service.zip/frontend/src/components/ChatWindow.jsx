import { useState, useEffect, useRef } from "react";
import { postJSON, getJSON } from "../lib/api";
import data from "@emoji-mart/data";
import Picker from "@emoji-mart/react";

export default function ChatWindow({ activeUser, currentUser }) {
  const [text, setText] = useState("");
  const [messages, setMessages] = useState([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [attachment, setAttachment] = useState(null);
  const [lastReadTimestamp, setLastReadTimestamp] = useState<string | null>(
    null
  );

  const pickerRef = useRef(null);
  const messagesEndRef = useRef(null);

  const log = (...args) => console.log("💬 [ChatWindow]", ...args);

  /* ----------------------------------------------------
     LOAD MESSAGES
  ---------------------------------------------------- */
  async function loadMessages() {
    if (!activeUser || !currentUser) return;
    try {
      let url = "";
      if (activeUser.type === "group")
        url = `/messages?groupid=${encodeURIComponent(
          activeUser.id
        )}&username=${encodeURIComponent(currentUser)}`;
      else if (activeUser.type === "user")
        url = `/messages?userA=${encodeURIComponent(
          currentUser
        )}&userB=${encodeURIComponent(activeUser.username)}`;

      const res = await getJSON(url);
      setMessages(res?.data || []);
    } catch (err) {
      console.error("❌ Failed to load messages:", err);
    }
  }

  /* ----------------------------------------------------
     MARK CHAT AS READ
  ---------------------------------------------------- */
  async function markAsRead() {
    if (!activeUser || !currentUser) return;

    try {
      const chatId =
        activeUser.type === "group"
          ? activeUser.id
          : `CHAT#${[activeUser.username, currentUser]
              .sort()
              .join("#")}`;

      await postJSON("/messages/mark-read", {
        chatId,
        username: currentUser,
      });

      setLastReadTimestamp(new Date().toISOString());
    } catch (err) {
      console.error("❌ Failed to mark chat as read:", err);
    }
  }

  useEffect(() => {
    if (!activeUser) return;
    loadMessages().then(() => markAsRead());
  }, [activeUser]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  /* ----------------------------------------------------
     SEND MESSAGE
  ---------------------------------------------------- */
  async function sendMessage(e) {
    e.preventDefault();
    if ((!text.trim() && !attachment) || !activeUser) return;

    try {
      let fileKey = null;
      let fileType = null;

      if (attachment) {
        console.log("📤 Uploading attachment:", attachment);
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () =>
            resolve(reader.result.split(",")[1]);
          reader.onerror = reject;
          reader.readAsDataURL(attachment);
        });

        const uploadRes = await postJSON("/files", {
          base64,
          name: attachment.name,
          type: attachment.type,
        });

        if (uploadRes?.success) {
          fileKey = uploadRes.key;
          fileType = attachment.type;
        }
      }

      const payload =
        activeUser.type === "group"
          ? {
              sender: currentUser,
              groupid: activeUser.id,
              text: text || null,
              attachmentKey: fileKey,
              attachmentType: fileType,
            }
          : {
              sender: currentUser,
              recipient: activeUser.username,
              text: text || null,
              attachmentKey: fileKey,
              attachmentType: fileType,
            };

      await postJSON("/messages", payload);
      setText("");
      setAttachment(null);
      setShowEmojiPicker(false);
      await loadMessages();
      await markAsRead();
    } catch (err) {
      console.error("❌ Failed to send message:", err);
    }
  }

  /* ----------------------------------------------------
     EMOJI PICKER + FILE HANDLERS
  ---------------------------------------------------- */
  const toggleEmojiPicker = () => setShowEmojiPicker((p) => !p);
  const handleEmojiSelect = (emoji) => setText((t) => t + emoji.native);

  useEffect(() => {
    const closePicker = (e) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target))
        setShowEmojiPicker(false);
    };
    document.addEventListener("mousedown", closePicker);
    return () => document.removeEventListener("mousedown", closePicker);
  }, []);

  const handleFileChange = (file) => file && setAttachment(file);
  const removeAttachment = () => setAttachment(null);

  /* ----------------------------------------------------
     RENDER
  ---------------------------------------------------- */
  function renderMessages() {
    let dividerShown = false;

    return messages.map((msg) => {
      const isUnread =
        lastReadTimestamp &&
        !dividerShown &&
        new Date(msg.createdAt) > new Date(lastReadTimestamp);

      if (isUnread) {
        dividerShown = true;
        return (
          <div key={msg.messageid || `${msg.sender}-${msg.createdAt}`}>
            <div className="text-center text-gray-400 text-xs my-3">
              — New Messages —
            </div>
            {renderBubble(msg)}
          </div>
        );
      }
      return renderBubble(msg);
    });
  }

  function renderBubble(msg) {
    return (
      <div
        key={msg.messageid || `${msg.sender}-${msg.createdAt}`}
        className={`p-3 rounded-lg max-w-[70%] ${
          msg.sender === currentUser
            ? "ml-auto bg-blue-600 text-white"
            : "mr-auto bg-white border"
        }`}
      >
        {msg.text && (
          <div className="whitespace-pre-wrap break-words">{msg.text}</div>
        )}

        {msg.attachmentKey && (
          <div className="mt-2">
            {msg.attachmentType?.startsWith("image/") ? (
              <img
                src={`${import.meta.env.VITE_API_BASE}/attachments?key=${encodeURIComponent(
                  msg.attachmentKey
                )}`}
                alt="Attachment"
                className="max-w-xs rounded-lg border"
              />
            ) : (
              <a
                href={`${import.meta.env.VITE_API_BASE}/attachments?key=${encodeURIComponent(
                  msg.attachmentKey
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="underline text-blue-200 hover:text-blue-400"
              >
                📎 {msg.attachmentKey.split("/").pop()}
              </a>
            )}
          </div>
        )}

        <div className="text-xs text-slate-400 mt-1">
          {new Date(msg.createdAt).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col flex-1 bg-slate-50 relative">
      {/* Header */}
      <div className="border-b bg-white p-4 font-semibold text-slate-700">
        {activeUser
          ? activeUser.type === "group"
            ? `Group: ${activeUser.name}`
            : `Chatting with ${activeUser.username}`
          : "Welcome to CHATr"}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-3">
        {activeUser ? (
          messages.length ? (
            renderMessages()
          ) : (
            <p className="text-center text-slate-400 italic">
              No messages yet
            </p>
          )
        ) : (
          <p className="text-center text-slate-400 italic mt-10">
            Select a contact or group to start chatting
          </p>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      {activeUser && (
        <div className="border-t bg-white p-3 relative">
          <form onSubmit={sendMessage} className="flex flex-col gap-2">
            {attachment && (
              <div className="flex items-center gap-3 border p-2 rounded-md bg-slate-100">
                {attachment.type.startsWith("image/") ? (
                  <img
                    src={URL.createObjectURL(attachment)}
                    alt="preview"
                    className="h-16 w-16 object-cover rounded"
                  />
                ) : (
                  <span className="text-sm text-slate-600">
                    📎 {attachment.name}
                  </span>
                )}
                <button
                  type="button"
                  onClick={removeAttachment}
                  className="text-red-500 hover:text-red-700 text-sm"
                >
                  ✕
                </button>
              </div>
            )}

            <div className="flex items-center gap-2">
              <div className="relative">
                <button
                  type="button"
                  onClick={toggleEmojiPicker}
                  className="text-2xl text-slate-500 hover:text-blue-600 transition"
                >
                  😊
                </button>
                {showEmojiPicker && (
                  <div
                    ref={pickerRef}
                    className="absolute bottom-12 left-0 z-50 shadow-xl border rounded-lg bg-white"
                  >
                    <Picker
                      data={data}
                      theme="light"
                      onEmojiSelect={handleEmojiSelect}
                    />
                  </div>
                )}
              </div>

              <label className="cursor-pointer text-xl text-slate-500 hover:text-blue-600">
                📎
                <input
                  type="file"
                  hidden
                  onChange={(e) => handleFileChange(e.target.files[0])}
                />
              </label>

              <input
                type="text"
                placeholder="Type your message..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="flex-1 border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
              />

              <button
                type="submit"
                className="bg-blue-600 text-white rounded-lg px-4 py-2 font-medium hover:bg-blue-700"
              >
                Send
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
