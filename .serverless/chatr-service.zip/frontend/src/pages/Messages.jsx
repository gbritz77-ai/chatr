// src/pages/Messages.jsx
import { useState } from "react";
import Sidebar from "../components/Sidebar";
import ChatWindow from "../components/ChatWindow";

export default function Messages() {
  const [activeUser, setActiveUser] = useState(null);
  const currentUser = localStorage.getItem("username") || "Anonymous";

  // ==========================================================
  // 📤 Handle File Upload (attachments)
  // ==========================================================
  const handleFileUpload = async (file) => {
    try {
      console.log("📦 Preparing file upload:", file);

      // Convert file to base64
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result.split(",")[1]; // Remove prefix "data:...;base64,"
          resolve(result);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Build upload payload
      const body = {
        base64,
        name: file.name,
        type: file.type,
      };

      console.log("🚀 Uploading to /files:", body.name);

      const res = await fetch("http://localhost:3000/dev/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const json = await res.json();
      console.log("✅ File uploaded successfully:", json);

      if (!json.success) throw new Error(json.message || "Upload failed");

      return json; // Returns { success, key, url }
    } catch (err) {
      console.error("❌ File upload failed:", err);
      alert(`File upload failed: ${err.message}`);
      return null;
    }
  };

  // ==========================================================
  // 🧩 Pass uploader into ChatWindow
  // ==========================================================
  return (
    <div className="h-screen w-screen flex overflow-hidden bg-slate-50 text-slate-800">
      {/* Sidebar sends selected user/group here */}
      <Sidebar onSelectUser={setActiveUser} currentUser={currentUser} />

      {/* Main chat window with upload handler */}
      <main className="flex-1 flex flex-col">
        <ChatWindow
          activeUser={activeUser}
          currentUser={currentUser}
          onUploadFile={handleFileUpload}
        />
      </main>
    </div>
  );
}
