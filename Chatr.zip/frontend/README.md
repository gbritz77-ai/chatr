# CHATr Frontend

This is the frontend web interface for CHATr.

### Features
- Dark/Light theme toggle
- Simple chat simulation
- Animated messages
- Clean, responsive layout

### To run locally
```bash
cd frontend
npx serve .
