export default {
  region: 'eu-west-2',
  tableName: process.env.TABLE_NAME,
  bucketName: process.env.BUCKET_NAME,
};
