import AWS from 'aws-sdk';
import { success, failure } from '../utils/response.js';

const s3 = new AWS.S3();

export const handler = async (event) => {
  try {
    const bucket = process.env.BUCKET_NAME;
    const { fileName } = JSON.parse(event.body);
    const url = s3.getSignedUrl('putObject', {
      Bucket: bucket,
      Key: fileName,
      Expires: 60 * 5,
    });
    return success({ uploadUrl: url });
  } catch (err) {
    return failure(err);
  }
};
