const bcrypt = require('bcryptjs');
const { signToken } = require('../utils/auth');
const { success, failure } = require('../utils/response');

module.exports.handler = async (event) => {
  try {
    const { username, password } = JSON.parse(event.body || '{}');
    if (!username || !password) throw new Error('Missing credentials');

    // ✅ Freshly generated hash for password: test123
    const storedPassword = '$2b$10$WisYbfkOvObaYAlOxAtkr.xykA77tvICQMMtN8POLOAJH9d2C1NVe';

    const valid = await bcrypt.compare(password, storedPassword);
    if (!valid) throw new Error('Invalid username or password');

    const token = signToken({ username });
    return success({ token });
  } catch (err) {
    console.error('Auth error:', err);
    return failure(err);
  }
};
