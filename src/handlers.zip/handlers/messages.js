const { v4: uuidv4 } = require('uuid');
const { put, getAll } = require('../utils/dynamodb');
const { success, failure } = require('../utils/response');
const { verifyToken } = require('../utils/auth');

module.exports.handler = async (event) => {
  const table = process.env.TABLE_NAME;

  try {
    // 🔐 Verify auth
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader) throw new Error('Missing Authorization header');

    const token = authHeader.replace('Bearer ', '');
    const decoded = verifyToken(token);
    if (!decoded) throw new Error('Invalid or expired token');

    // 📬 POST = add message
    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      const item = {
        id: uuidv4(),
        sender: decoded.username,
        text: body.text || '',
        createdAt: new Date().toISOString(),
      };

      await put(table, item);
      console.log('✅ Message saved:', item);
      return success(item);
    }

    // 📖 GET = list messages
    else if (event.httpMethod === 'GET') {
      const items = await getAll(table);
      return success(items);
    }

    else {
      return failure(new Error('Unsupported method'), 405);
    }

  } catch (err) {
    console.error('Messages handler error:', err);
    return failure(err);
  }
};
